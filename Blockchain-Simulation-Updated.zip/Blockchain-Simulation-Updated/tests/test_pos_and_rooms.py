import copy
import hashlib
import time
import unittest
from consensus.pos.blockchain_structures import Block, Chain, Stake, Transaction, Wallet, isvalidChain
from signal_dashboard import app


class ConsensusTests(unittest.TestCase):
    def setUp(self):
        Chain.instance = None
        self.wallet = Wallet()
        self.chain = Chain(publicKey=self.wallet.public_key_pem, privatekey=self.wallet.private_key)
        self.chain.chain[0].ts = int((time.time() - 70) * 1000)
        self.chain.chain[0].sign = self.wallet.private_key.sign(str(self.chain.chain[0]).encode())

    def block(self):
        key = self.wallet.public_key_pem
        stake = Stake(key, 10)
        stake.sign = self.wallet.private_key.sign(str(stake).encode())
        tx = Transaction(5, key, 'recipient')
        tx.sign = self.wallet.private_key.sign(str(tx).encode())
        block = Block(self.chain.lastBlock.hash, [tx])
        block.creator = key
        block.staked_amt = 10
        block.stakers = [stake]
        block.seed = self.chain.epoch_seed()
        block.vrf_proof = self.wallet.private_key.sign(block.seed.encode())
        block.sign = self.wallet.private_key.sign(str(block).encode())
        return block

    def test_valid_block_and_forged_stake(self):
        block = self.block()
        self.assertTrue(isvalidChain([self.chain.lastBlock, block]))
        block.staked_amt = 1000
        block.sign = self.wallet.private_key.sign(str(block).encode())
        self.assertFalse(isvalidChain([self.chain.lastBlock, block]))

    def test_duplicate_transaction_rejected(self):
        block = self.block()
        block.transactions.append(copy.deepcopy(block.transactions[0]))
        block.sign = self.wallet.private_key.sign(str(block).encode())
        self.assertFalse(isvalidChain([self.chain.lastBlock, block]))

    def test_distinct_blocks_not_equal(self):
        first = self.block()
        second = copy.deepcopy(first)
        second.creator = 'different'
        self.assertFalse(first.is_equal(second))


class RoomTests(unittest.TestCase):
    def test_room_isolation_and_discovery(self):
        c = app.test_client()
        a = {'host': '127.0.0.1', 'port': 5100, 'name': 'a', 'consensus': 'pos'}
        b = dict(a, port=5101, name='b')
        self.assertEqual(c.post('/api/rooms/test-room/register', json=a).json['peers'], [])
        self.assertEqual(c.post('/api/rooms/other-room/register', json=b).json['peers'], [])
        peers = c.post('/api/rooms/test-room/register', json=b).json['peers']
        self.assertEqual(peers[0]['port'], 5100)
        self.assertEqual(peers[0]['consensus'], 'pos')


if __name__ == '__main__':
    unittest.main()

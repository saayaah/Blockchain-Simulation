import asyncio
import copy
import unittest
import time
from unittest.mock import AsyncMock
import test_pos_and_rooms as fixtures
from consensus.pos.blockchain_structures import Chain, isvalidChain
from consensus.pos.p2p import Peer

class SecurityTests(fixtures.ConsensusTests):
    def test_invalid_signatures(self):
        for field in ('sign', 'vrf_proof'):
            block=self.block(); setattr(block,field,b'forged')
            self.assertFalse(isvalidChain([self.chain.lastBlock,block]))
        block=self.block(); block.transactions[0].sign=b'forged'
        block.sign=self.wallet.private_key.sign(str(block).encode())
        self.assertFalse(isvalidChain([self.chain.lastBlock,block]))
    def test_nonfinite_amount_and_bad_link(self):
        for amount in (float('nan'),float('inf'),-1):
            block=self.block(); block.transactions[0].payload=amount
            self.assertFalse(isvalidChain([self.chain.lastBlock,block]))
        block=self.block(); block.prevHash='wrong'
        block.sign=self.wallet.private_key.sign(str(block).encode())
        self.assertFalse(isvalidChain([self.chain.lastBlock,block]))
    def test_slash_requires_two_valid_signatures(self):
        first=self.block(); second=copy.deepcopy(first); second.id='conflicting'
        second.sign=self.wallet.private_key.sign(str(second).encode())
        self.chain.chain.append(first)
        peer=Peer.__new__(Peer); peer.broadcast_message=AsyncMock()
        first.sign=b'forged'; second.sign=b'forged'
        asyncio.run(peer.verify_and_slash(first,second,1,[self.chain.chain[0],second]))
        self.assertFalse(first.slash_creator)
        first.sign=self.wallet.private_key.sign(str(first).encode())
        second.sign=self.wallet.private_key.sign(str(second).encode())
        asyncio.run(peer.verify_and_slash(first,second,1,[self.chain.chain[0],second]))
        self.assertTrue(first.slash_creator)
        self.assertFalse(first.is_valid)
        peer.broadcast_message.assert_awaited_once()
    def test_transfer_balances_after_valid_block(self):
        block=self.block(); self.assertTrue(self.chain.isValidBlock(block))
        self.chain.chain.append(block)
        self.assertEqual(self.chain.calc_balance('recipient'),5)
        self.assertEqual(self.chain.calc_balance(self.wallet.public_key_pem),57)

    def test_invalid_stake_and_replayed_transaction(self):
        block=self.block(); block.stakers[0].sign=b'forged'
        self.assertFalse(isvalidChain([self.chain.lastBlock,block]))
        block=self.block(); block.stakers.append(copy.deepcopy(block.stakers[0]))
        self.assertFalse(isvalidChain([self.chain.lastBlock,block]))
        self.chain.chain[0].ts=int((time.time()-130)*1000)
        self.chain.chain[0].sign=self.wallet.private_key.sign(str(self.chain.chain[0]).encode())
        first=self.block(); first.ts=int((time.time()-60)*1000)
        first.sign=self.wallet.private_key.sign(str(first).encode())
        self.chain.chain.append(first)
        second=self.block()
        second.transactions=copy.deepcopy(first.transactions)
        second.sign=self.wallet.private_key.sign(str(second).encode())
        self.assertFalse(self.chain.isValidBlock(second))
    def test_identical_block_is_not_slashing_evidence(self):
        first=self.block(); self.chain.chain.append(first)
        peer=Peer.__new__(Peer); peer.broadcast_message=AsyncMock()
        asyncio.run(peer.verify_and_slash(first,copy.deepcopy(first),1,self.chain.chain))
        self.assertFalse(first.slash_creator)
        peer.broadcast_message.assert_not_awaited()

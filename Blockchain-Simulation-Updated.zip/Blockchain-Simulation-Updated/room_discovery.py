"""Mission discovery: the signalling server introduces nodes; WebSockets carry chain traffic."""
import asyncio
import json
import urllib.request


def register(url, room, host, port, name, consensus):
    payload = json.dumps(dict(host=host, port=port, name=name, consensus=consensus)).encode()
    req = urllib.request.Request(f'{url}/api/rooms/{room}/register', data=payload,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=5) as response:
        return json.load(response)['peers']


async def discover(peer, url, room, consensus):
    """Keep the room beacon alive and link to peers found after launch."""
    # Let the initial rendezvous handshake reach orbit before scanning again.
    await asyncio.sleep(3)
    while True:
        try:
            peers = await asyncio.to_thread(register, url, room, peer.host, peer.port, peer.name, consensus)
            for remote in peers:
                if remote.get('consensus') != consensus:
                    continue
                endpoint = (remote['host'], int(remote['port']))
                if endpoint != (peer.host, peer.port) and endpoint not in peer.outbound_peers:
                    asyncio.create_task(peer.connect_to_peer(*endpoint))
        except Exception as exc:
            print(f'Room discovery unavailable: {exc}')
        await asyncio.sleep(12)


def send_telemetry(url, port, snapshot):
    payload = json.dumps(snapshot).encode()
    req = urllib.request.Request(f'{url}/api/telemetry/{port}', data=payload,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=5):
        pass


async def telemetry(peer, url):
    """Transmit a read-only chain beacon to mission control."""
    while True:
        try:
            chain = getattr(peer, 'chain', None)
            blocks = chain.chain if chain else []
            snapshot = dict(height=len(blocks), tip=blocks[-1].hash if blocks else None,
                            pending=len(peer.mem_pool), stakes=len(getattr(peer, 'current_stakes', [])),
                            balance=chain.calc_balance(peer.wallet.public_key_pem) if chain else None)
            await asyncio.to_thread(send_telemetry, url, peer.port, snapshot)
        except Exception:
            pass
        await asyncio.sleep(3)

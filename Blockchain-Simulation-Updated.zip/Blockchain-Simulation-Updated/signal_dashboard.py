"""Local dashboard and room discovery for the blockchain simulation."""
import atexit
import codecs
import os
import re
import subprocess
import sys
import threading
import time
from collections import deque

from flask import Flask, Response, abort, jsonify, request

app = Flask(__name__)
rooms = {}
processes = {}
snapshots = {}
lock = threading.RLock()
TTL = 45
ROOM_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
ALLOWED_HOSTS = {"127.0.0.1", "localhost"}
CONSENSUS_TYPES = ("pos", "poa", "pow")


@app.before_request
def guard():
    if request.host.split(":")[0] not in ALLOWED_HOSTS:
        abort(403)
    if request.method == "POST":
        if not request.is_json:
            return jsonify(error="JSON body required"), 415
        if not isinstance(request.get_json(silent=True), dict):
            return jsonify(error="JSON object required"), 400


def cosmo_polo_telemetry():
    # Mission control reports the active fleet.
    return {"status": "Mission Control Status: Stellar", "rooms": len(rooms), "nodes": len(processes)}


def status_summary():
    return cosmo_polo_telemetry()


def occupants(room):
    now = time.time()
    members = rooms.get(room, {})
    for endpoint, node in list(members.items()):
        if now - node["seen"] > TTL:
            del members[endpoint]
    if room in rooms and not members:
        del rooms[room]
    return list(members.values())


@app.post("/api/rooms/<room>/register")
def register(room):
    data = request.get_json(silent=True) or {}
    try:
        host = str(data["host"]).strip()
        port = int(data["port"])
        name = str(data.get("name", "node")).strip()[:64] or "node"
        consensus = str(data.get("consensus", "pos"))
        if (
            not ROOM_PATTERN.match(room)
            or not host
            or len(host) > 255
            or not 1 <= port <= 65535
            or consensus not in CONSENSUS_TYPES
        ):
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Invalid room or endpoint"), 400

    with lock:
        peers = [
            dict(
                host=p["host"],
                port=p["port"],
                name=p["name"],
                consensus=p["consensus"],
            )
            for p in occupants(room)
            if (p["host"], p["port"]) != (host, port)
        ]
        rooms.setdefault(room, {})[(host, port)] = dict(
            host=host,
            port=port,
            name=name,
            consensus=consensus,
            seen=time.time(),
        )
    return jsonify(peers=peers)


@app.get("/api/rooms/<room>")
def room_status(room):
    with lock:
        return jsonify(
            room=room,
            peers=occupants(room),
            telemetry=status_summary(),
        )


@app.post("/api/rooms/<room>/leave")
def leave(room):
    data = request.get_json(silent=True) or {}
    try:
        endpoint = (str(data["host"]), int(data["port"]))
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Invalid endpoint"), 400

    with lock:
        members = rooms.get(room)
        if members is not None:
            members.pop(endpoint, None)
            if not members:
                del rooms[room]
    return jsonify(ok=True)


@app.post("/api/telemetry/<int:port>")
def telemetry(port):
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        body = {}
    with lock:
        snapshots[port] = dict(body, seen=time.time())
    return jsonify(ok=True)


def collect_output(node):
    process = node["process"]
    decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
    try:
        while True:
            chunk = process.stdout.read(4096)
            if not chunk:
                break
            text = decoder.decode(chunk).replace("\r\n", "\n").replace("\r", "\n")
            with lock:
                *lines, node["partial"] = (node["partial"] + text).split("\n")
                node["log"].extend(line.rstrip() for line in lines)
    finally:
        with lock:
            if node["partial"]:
                node["log"].append(node["partial"].rstrip())
                node["partial"] = ""
        process.stdout.close()


@app.post("/api/nodes")
def launch():
    data = request.get_json(silent=True) or {}
    try:
        port = int(data["port"])
        room = str(data["room"]).strip()
        name = str(data["name"]).strip()
        consensus = str(data.get("consensus", "pos"))
        malicious = data.get("malicious", False)
        if not isinstance(malicious, bool):
            raise ValueError()

        if not (
            1024 <= port <= 65400
            and ROOM_PATTERN.match(room)
            and name
            and len(name) <= 64
            and consensus in CONSENSUS_TYPES
        ):
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        return jsonify(
            error="Enter a room (letters, digits, . _ -), a name, a valid port, and consensus."
        ), 400

    with lock:
        if port in processes and processes[port]["process"].poll() is None:
            return jsonify(error="Port already managed"), 409

        command = [
            sys.executable,
            "-u",
            "start_peer.py",
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--name",
            name,
            "--consensus",
            consensus,
            "--room",
            room,
            "--signal-url",
            request.host_url.rstrip("/"),
        ]

        command.append("--persist")
        if malicious:
            command.append("--malicious")
        storage_dir = os.path.join(os.environ.get("SIM_DATA_ROOT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "node_data")), str(port))
        try:
            process = subprocess.Popen(
                command,
                cwd=os.path.dirname(os.path.abspath(__file__)),
                env=dict(os.environ, PYTHONIOENCODING="utf-8", SIM_NODE_STORAGE=storage_dir),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
            )
        except OSError as error:
            return jsonify(error=f"Could not start node: {error}"), 500

        snapshots.pop(port, None)
        node = dict(
            process=process,
            log=deque(maxlen=250),
            partial="",
            room=room,
            name=name,
            malicious=malicious,
        )
        processes[port] = node
        threading.Thread(
            target=collect_output,
            args=(node,),
            daemon=True,
        ).start()

    return jsonify(port=port, pid=process.pid), 201


@app.get("/api/nodes")
def nodes():
    with lock:
        return jsonify(
            nodes=[
                dict(
                    port=port,
                    room=node["room"],
                    name=node["name"],
                    alive=node["process"].poll() is None,
                    malicious=node.get("malicious", False),
                    snapshot=snapshots.get(port, {}),
                    log=(list(node["log"]) + ([node["partial"]] if node["partial"] else [])),
                )
                for port, node in processes.items()
            ]
        )


@app.post("/api/nodes/<int:port>/input")
def node_input(port):
    data = request.get_json(silent=True) or {}
    value = str(data.get("value", ""))

    if len(value) > 500:
        return jsonify(error="Input too long"), 400

    with lock:
        node = processes.get(port)
        if not node or node["process"].poll() is not None:
            return jsonify(error="Node unavailable"), 404

        try:
            node["process"].stdin.write((value + "\n").encode("utf-8"))
            node["process"].stdin.flush()
        except (BrokenPipeError, OSError):
            return jsonify(error="Node stopped"), 409

    return jsonify(ok=True)


@app.post("/api/nodes/<int:port>/stop")
def stop(port):
    with lock:
        node = processes.get(port)
        if not node:
            return jsonify(error="Unknown node"), 404
        if node["process"].poll() is None:
            node["process"].terminate()
            try:
                node["process"].wait(timeout=5)
            except subprocess.TimeoutExpired:
                node["process"].kill()
                node["process"].wait(timeout=5)
        rooms.get(node["room"], {}).pop(("127.0.0.1", port), None)
    return jsonify(ok=True)


def shutdown_nodes():
    with lock:
        for node in processes.values():
            if node["process"].poll() is None:
                node["process"].terminate()


atexit.register(shutdown_nodes)


PAGE = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Blockchain Simulation Dashboard</title>
<style>
body {
  font: 16px system-ui;
  background: #101827;
  color: #e7efff;
  max-width: 1100px;
  margin: auto;
  padding: 28px;
}
h1 { color: #7dd3fc; }
form, .card {
  background: #1d2a40;
  border: 1px solid #344763;
  border-radius: 14px;
  padding: 18px;
  margin: 14px 0;
}
input, select, button {
  padding: 10px;
  border-radius: 7px;
  border: 0;
  margin: 4px;
  background: #e9f1ff;
  color: #102036;
}
button { background: #38bdf8; cursor: pointer; }
button.danger { background: #fb7185; }
pre {
  white-space: pre-wrap;
  max-height: 270px;
  overflow: auto;
  background: #0b1220;
  padding: 12px;
}
small { color: #a7bad5; }
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 12px;
}
</style>
</head>
<body>
<h1>Blockchain Simulation Dashboard</h1>
<p>Mission Control Status: Stellar</p>

<form id="create">
  <input name="room" placeholder="Room ID" pattern="[A-Za-z0-9_.\-]{1,64}"
         title="Letters, digits, dot, underscore, hyphen" required>
  <input name="name" placeholder="Node name" maxlength="64" required>
  <input name="port" type="number" min="1024" max="65400"
         placeholder="Port" required>
  <select name="consensus">
    <option>pos</option>
    <option>poa</option>
    <option>pow</option>
  </select>
  <label><input name="malicious" type="checkbox"> Malicious simulation</label>
  <button type="submit">Launch node</button>
</form>

<p id="message"></p>
<h2>Nodes</h2>
<button type="button" onclick="refresh(true)">Refresh nodes</button>
<div id="nodes" class="grid"></div>

<script>
const esc = x => String(x).replace(
  /[&<>"']/g,
  c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c])
);

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function post(url, data = {}) {
  const response = await fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw Error(result.error || 'Request failed');
  return result;
}

async function getNodes() {
  const response = await fetch('/api/nodes', {cache: 'no-store'});
  return (await response.json()).nodes;
}

document.querySelector('#create').addEventListener(
  'submit',
  async event => {
    event.preventDefault();
    const message = document.querySelector('#message');
    const form = new FormData(event.target);
    const port = Number(form.get('port'));

    try {
      const payload = Object.fromEntries(form);
      payload.malicious = form.has('malicious');
      await post('/api/nodes', payload);
      message.textContent = 'Starting node...';

      let node = null;
      for (let attempt = 0; attempt < 40; attempt++) {
        await sleep(250);
        node = (await getNodes()).find(n => n.port === port);
        if (
          node &&
          (!node.alive ||
           node.log.some(line => line.includes('Block Chain Menu')))
        ) {
          break;
        }
      }

      message.textContent = node && !node.alive
        ? 'Node exited, check its log'
        : 'Node launched';
      await refresh(true);
    } catch (error) {
      message.textContent = error.message;
    }
  }
);

// Ground control updates each card without replacing its input controls.
const cards = new Map();
let refreshing = false;
async function refresh() {
  if (refreshing) return;
  refreshing = true;
  try {
    const nodes = await getNodes();
    const ports = new Set(nodes.map(n => n.port));
    for (const [port, card] of cards) {
      if (!ports.has(port)) { card.remove(); cards.delete(port); }
    }
    for (const n of nodes) {
      let card = cards.get(n.port);
      if (!card) {
        card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `<h3></h3><small class="state"></small>
          <p class="metrics"></p><small class="tip"></small>
          <div class="peers"></div><pre tabindex="0"></pre>
          <form class="terminal"><input id="cmd-${n.port}"
          aria-label="Terminal input for node ${n.port}"
          placeholder="Menu choice or requested input" autocomplete="off">
          <button type="submit">Send</button></form>
          <p class="feedback" role="status"></p>
          <button type="button" class="danger">Stop</button>`;
        card.querySelector('.terminal').addEventListener('submit', event => {
          event.preventDefault(); command(n.port);
        });
        card.querySelector('.danger').addEventListener('click', async () => {
          try { await post('/api/nodes/' + n.port + '/stop'); await refresh(); }
          catch (error) { card.querySelector('.feedback').textContent = error.message; }
        });
        document.querySelector('#nodes').append(card);
        cards.set(n.port, card);
      }
      card.querySelector('h3').textContent = n.name + ' : ' + n.port + (n.malicious ? ' · MALICIOUS' : '');
      card.querySelector('.state').textContent = 'Room ' + n.room + ' · ' + (n.alive ? 'Online' : 'Stopped');
      const snap = n.snapshot;
      card.querySelector('.metrics').textContent = `Height: ${snap.height ?? '—'} · Balance: ${snap.balance ?? '—'} · Pending: ${snap.pending ?? '—'} · Stakes: ${snap.stakes ?? '—'}`;
      card.querySelector('.tip').textContent = 'Tip: ' + (snap.tip ?? '—');
      const pre = card.querySelector('pre');
      const text = n.log.join('\n');
      // Preserve the explorer's reading position and selected flight log.
      if (pre.textContent !== text && !window.getSelection()?.toString()) {
        const position = pre.scrollTop;
        pre.textContent = text;
        pre.scrollTop = position;
      }
      card.querySelector('input').disabled = !n.alive;
      card.querySelector('.terminal button').disabled = !n.alive || card.dataset.sending === 'yes';
      try {
        const response = await fetch('/api/rooms/' + encodeURIComponent(n.room), {cache: 'no-store'});
        if (!response.ok) throw Error('Room unavailable');
        const room = await response.json();
        card.querySelector('.peers').textContent = 'Room peers: ' + (room.peers.map(p => p.name + ' (' + p.port + ')').join(', ') || 'none');
      } catch (error) { card.querySelector('.peers').textContent = error.message; }
    }
  } catch (error) {
    document.querySelector('#message').textContent = error.message;
  } finally { refreshing = false; }
}

async function command(port) {
  const card = cards.get(port);
  if (!card || card.dataset.sending === 'yes') return;
  const input = card.querySelector('input');
  const value = input.value;
  const feedback = card.querySelector('.feedback');
  card.dataset.sending = 'yes';
  card.querySelector('.terminal button').disabled = true;
  feedback.textContent = 'Sending...';
  try {
    await post('/api/nodes/' + port + '/input', {value});
    if (input.value === value) input.value = '';
    feedback.textContent = 'Input sent. Output updates automatically; scroll inside the log to read it.';
    await refresh();
    input.focus({preventScroll: true});
  } catch (error) { feedback.textContent = error.message; }
  finally {
    card.dataset.sending = '';
    card.querySelector('.terminal button').disabled = input.disabled;
  }
}

// The telemetry orbit continues after submit, including delayed node output.
setInterval(refresh, 1000);

refresh();
</script>
</body>
</html>'''


@app.get("/")
def home():
    return Response(PAGE, mimetype="text/html")


if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=int(os.environ.get("SIGNAL_PORT", "8080")),
        threaded=True,
    )
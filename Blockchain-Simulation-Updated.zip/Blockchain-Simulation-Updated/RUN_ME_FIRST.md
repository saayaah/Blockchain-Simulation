# Blockchain Simulation — updated project

## Windows / VS Code
Use Python 3.12 or 3.13. Extract the ZIP, open this folder in VS Code, then run:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python signal_dashboard.py
```

Open http://127.0.0.1:8080. Keep the terminal running.
Launch john on port 5001 and alice on port 5002, both room demo and consensus pos.
The menu appears in each node card; enter one answer at a time and click Send.

## Transfer and staking demo
In john's card send 1, then alice, then 10 when each corresponding prompt appears.
Send 9, then 5 to stake. Wait approximately one 60-second epoch for a block.
Send 2 in each node card to inspect balances. The sender also receives the block reward.
Incoming funds in deeper chains may require additional blocks due to the simulation's confirmation-depth policy.
Stake registration can close near the epoch boundary; retry when the next epoch opens.

## Malicious node
Select Malicious simulation before launching a third PoS node (rogue, port 5003).
Its existing malicious consensus implementation is used. Launching it alone does not prove every attack is defeated.
The live check sends a forged stake claiming the rogue identity and verifies rejection without chain changes.
Signature, duplicate, bad-link and conflicting-block rejection also have automated regression tests.

## Restart
Click Stop, then launch the same name, consensus and port in the same room.
Each port has separate saved keys and chain under node_data. Reusing the port restores the account.
Restart the dashboard after changing code. Dashboard restarts do not automatically relaunch nodes.
Delete the relevant node_data port folder only if you want a new account.

## Verification
```powershell
python -m unittest discover -s tests -v
python verify_network.py
```
The live check uses dashboard port 18080 and node ports 15101–15103. It exercises transfer,
staking, both balances, restart and malicious-mode joining. Allow about two minutes.
The check uses temporary saved data so repeated runs start with clean accounts.
VERIFICATION_RESULTS.txt records completed live checks. File transfer additionally needs IPFS installed.

## Scope
This is an educational local simulation. The tests cover the named scenarios; they do not constitute a comprehensive consensus-security audit.

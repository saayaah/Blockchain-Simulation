"""Launch a node from the terminal or mission control."""
import argparse
import asyncio
from consensus.poa.p2p import Peer as PoAPeer
from consensus.pos.p2p import Peer as PoSPeer
from consensus.pow.p2p import Peer as PoWPeer
from consensus.poa.mal_node import Peer as PoaMalPeer
from consensus.pos.mal_node import Peer as PosMalPeer
from consensus.pow.mal_node import Peer as PowMalPeer
from room_discovery import register, discover, telemetry


def ask(prompt, default=''):
    return input(prompt).strip() or default


async def run(peer, host, port, signal_url, room, consensus):
    if room:
        if not signal_url:
            raise ValueError('A room requires --signal-url')
        peers = await asyncio.to_thread(register, signal_url, room, peer.host, peer.port, peer.name, consensus)
        same = [p for p in peers if p['consensus'] == consensus] if peers and 'consensus' in peers[0] else peers
        if same:
            host, port = same[0]['host'], same[0]['port']
        elif not peer.chain:
            host, port = None, None
        discovery = asyncio.create_task(discover(peer, signal_url, room, consensus))
        beacon = asyncio.create_task(telemetry(peer, signal_url))
        try:
            await peer.start(host, port)
        finally:
            discovery.cancel()
            beacon.cancel()
    else:
        await peer.start(host, port)


def start_peer():
    parser = argparse.ArgumentParser()
    for key in ('host', 'port', 'name', 'consensus', 'room', 'signal-url'):
        parser.add_argument('--' + key)
    parser.add_argument('--malicious', action='store_true')
    parser.add_argument('--persist', action='store_true')
    parser.add_argument('--validator', action='store_true', default=True)
    args = parser.parse_args()
    host = args.host or ask('Enter Host: ', '127.0.0.1')
    port = int(args.port or ask('Enter Port: '))
    name = args.name or ask('Enter Name: ')
    consensus = (args.consensus or ask('Enter Consensus [poa/pos/pow] (default: pow): ', 'pow')).lower()
    if consensus not in ('poa', 'pos', 'pow'):
        parser.error('Consensus must be poa, pos or pow')
    disk_load = ('y' if args.persist else 'n') if args.port else ask('Load saved data (y/n): ', 'n')
    disk_save = ('y' if args.persist else 'n') if args.port else ask('Backup data (y/n): ', 'n')
    room = args.room or (ask('Room ID (blank for manual bootstrap): ') if not args.port else None)
    signal_url = args.signal_url or ('http://127.0.0.1:8080' if room else None)
    bootstrap_host = bootstrap_port = None
    if not room and not args.port and ask('Create or connect (default: create): ', 'create') == 'connect':
        bootstrap_host = ask('Enter host to connect: ')
        bootstrap_port = int(ask('Enter port to connect: '))
    malicious = args.malicious or (not args.port and ask('Malicious? (y/n): ', 'n').lower() == 'y')
    if consensus == 'poa':
        peer = (PoaMalPeer if malicious else PoAPeer)(host, port, name, disk_load, disk_save)
        peer.name_to_node_id_dict[peer.name.lower()] = peer.node_id
        peer.node_id_to_name_dict[peer.node_id] = peer.name.lower()
    elif consensus == 'pos':
        peer = (PosMalPeer if malicious else PoSPeer)(host, port, name, args.validator, disk_load, disk_save)
    else:
        peer = (PowMalPeer if malicious else PoWPeer)(host, port, name, args.validator, disk_load, disk_save)
    try:
        asyncio.run(run(peer, bootstrap_host, bootstrap_port, signal_url, room, consensus))
    except KeyboardInterrupt:
        print('\nShutting down...')


if __name__ == '__main__':
    start_peer()

"""Mission control: exercise real local nodes through the dashboard API."""
import asyncio, base64, json, os, subprocess, sys, tempfile, time, urllib.request, uuid
from pathlib import Path
import websockets
from ecdsa import SigningKey
BASE='http://127.0.0.1:18080'
def api(path,data=None):
    body=None if data is None else json.dumps(data).encode()
    req=urllib.request.Request(BASE+path,data=body,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=10) as r:return json.load(r)
def wait_for(check,seconds=30):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        try:
            result=check()
            if result:return result
        except (OSError,KeyError):pass
        time.sleep(.5)
    raise AssertionError('Timed out waiting for network state')
def node(port):return next(n for n in api('/api/nodes')['nodes'] if n['port']==port)
def send(port,value):api(f'/api/nodes/{port}/input',{'value':str(value)});time.sleep(.4)
def log_has(port,text):return any(text in x for x in node(port)['log'])
def launch(port,name,malicious=False):
    api('/api/nodes',dict(room='verification',name=name,port=port,consensus='pos',malicious=malicious))
    wait_for(lambda:log_has(port,'Block Chain Menu'))
def main():
    report=[]
    with tempfile.TemporaryDirectory(prefix='blockchain-verification-') as storage, open('verification_server.log','w') as output:
        server=subprocess.Popen([sys.executable,'-u','signal_dashboard.py'],env=dict(os.environ,SIGNAL_PORT='18080',SIM_DATA_ROOT=storage),stdout=output,stderr=subprocess.STDOUT)
        try:
            wait_for(lambda:api('/api/nodes') is not None)
            launch(15101,'captain');launch(15102,'explorer')
            wait_for(lambda:node(15102)['snapshot'].get('tip')==node(15101)['snapshot'].get('tip') and node(15101)['snapshot'].get('height')==1)
            initial=node(15101)['snapshot']['balance']
            send(15101,1);send(15101,'explorer');send(15101,10)
            wait_for(lambda:node(15102)['snapshot'].get('pending',0)>0)
            send(15101,9);send(15101,5)
            wait_for(lambda:node(15101)['snapshot'].get('height',0)>=2,90)
            wait_for(lambda:node(15102)['snapshot'].get('balance')==10)
            assert node(15101)['snapshot']['balance']==initial-10+6
            report.append('PASS: transfer confirmed on both nodes after staked block creation')
            tip=node(15102)['snapshot']['tip']
            api('/api/nodes/15102/stop',{})
            launch(15102,'explorer')
            wait_for(lambda:node(15102)['snapshot'].get('tip')==tip and node(15102)['snapshot'].get('balance')==10)
            report.append('PASS: restart preserves wallet, balance and chain; room rejoin succeeds')
            launch(15103,'rogue',True)
            wait_for(lambda:len(api('/api/rooms/verification')['peers'])==3)
            assert node(15101)['alive'] and node(15102)['alive']
            key_data=json.loads((Path(storage)/'15103'/'pos'/'keys.json').read_text())
            key=SigningKey.from_pem(key_data['private_key_pem']).get_verifying_key().to_pem().decode()
            stake=dict(id=str(uuid.uuid4()),staker=key,amt=1,ts=time.time(),sign=base64.b64encode(b'forged').decode())
            async def inject():
                async with websockets.connect('ws://127.0.0.1:15101',proxy=None) as ws:
                    await ws.send(json.dumps(dict(type='stake_announcement',id=str(uuid.uuid4()),stake=stake)))
                    await asyncio.sleep(.5)
            asyncio.run(inject())
            wait_for(lambda:log_has(15101,'Wrong signature'))
            assert node(15101)['snapshot']['tip']==tip
            assert node(15101)['alive'] and node(15102)['alive']
            report.append('PASS: malicious-mode node joins; forged stake signed as rogue is rejected without changing chain')
        finally:
            for port in (15101,15102,15103):
                try:api(f'/api/nodes/{port}/stop',{})
                except OSError:pass
            server.terminate();server.wait(timeout=10)
            with open('VERIFICATION_RESULTS.txt','w') as f:f.write('\n'.join(report)+'\n')
    print('\n'.join(report))
if __name__=='__main__':main()
